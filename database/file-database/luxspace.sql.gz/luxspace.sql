-- Adminer 4.8.1 MySQL 5.7.33 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `carts`;
CREATE TABLE `carts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `users_id` bigint(20) NOT NULL,
  `products_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_resets_table',	1),
(3,	'2014_10_12_200000_add_two_factor_columns_to_users_table',	1),
(4,	'2019_08_19_000000_create_failed_jobs_table',	1),
(5,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(6,	'2023_02_17_133917_create_sessions_table',	1),
(7,	'2023_02_17_134810_add_roles_to_users_table',	1),
(8,	'2023_02_17_135401_create_products_table',	1),
(9,	'2023_02_17_141030_create_product_galleries_table',	1),
(10,	'2023_02_17_141346_create_carts_table',	1),
(11,	'2023_02_17_141654_create_transactions_table',	1),
(12,	'2023_02_17_142449_create_transaction_items_table',	1);

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `products` (`id`, `name`, `price`, `description`, `slug`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1,	'MILLBERGET',	1799000,	'<h1>Kursi putar, murum hitam</h1>',	'millberget',	NULL,	'2023-02-21 23:22:15',	'2023-02-21 23:23:27'),
(2,	'STRANDTORP',	7299000,	'<h1>Meja yang dapat dipanjangkan, cokelat, 150/205/260x95 cm</h1>',	'strandtorp',	NULL,	'2023-02-21 23:28:45',	'2023-02-21 23:28:45'),
(3,	'MELODI',	199000,	'<h1>Lampu gantung, putih, 38 cm</h1>',	'melodi',	NULL,	'2023-02-22 00:07:38',	'2023-02-22 00:07:38'),
(4,	'ELLOVEN',	349000,	'<h1>Meja monitor dengan laci, putih</h1>',	'elloven',	NULL,	'2023-02-22 00:14:57',	'2023-02-22 00:14:57'),
(5,	'SLÄKT',	4499000,	'<h1>Rangka tpt tdr dg bag. bwh &amp; pympn, putih, 90x200 cm</h1>',	'slakt',	NULL,	'2023-02-22 00:23:35',	'2023-02-22 00:23:35');

DROP TABLE IF EXISTS `product_galleries`;
CREATE TABLE `product_galleries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `products_id` bigint(20) NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_galleries` (`id`, `products_id`, `url`, `is_featured`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1,	1,	'public/gallery/Vn8Ego4xjbAG8Jga9xBb9E9xX1HQfZ7h5jKUZZrb.jpg',	0,	NULL,	'2023-02-21 23:22:41',	'2023-02-21 23:22:41'),
(2,	1,	'public/gallery/h5upO4Q2SYKelSRpIL56TrI8e6Y2EO87xisUZGWQ.jpg',	0,	NULL,	'2023-02-21 23:22:41',	'2023-02-21 23:22:41'),
(3,	1,	'public/gallery/KuonCw0wZ3CmTtqeZNyGxocdggwQr9w1oLC3YLto.jpg',	0,	NULL,	'2023-02-21 23:22:41',	'2023-02-21 23:22:41'),
(4,	1,	'public/gallery/Z4Ti7qi4HgfP1siRG2ojy0CBPCnRHIk077EUzS8n.jpg',	0,	NULL,	'2023-02-21 23:22:41',	'2023-02-21 23:22:41'),
(5,	1,	'public/gallery/hi5k2PRUslkgmGTBs1zjX6CGO9mXbIKT3EYQLGqQ.jpg',	0,	NULL,	'2023-02-21 23:22:41',	'2023-02-21 23:22:41'),
(6,	2,	'public/gallery/hexeuG5fVUewrP5BcGKZcilndnp5DiB8mMhapHAg.jpg',	0,	NULL,	'2023-02-21 23:28:56',	'2023-02-21 23:28:56'),
(7,	2,	'public/gallery/rHr08hS58qUPrm9NsntPoGSPQXiFMxQl8wt0V65Z.jpg',	0,	NULL,	'2023-02-21 23:28:56',	'2023-02-21 23:28:56'),
(8,	2,	'public/gallery/xKR5yMHN32yV0sgUEKed57TTD5HiSBHLmhoDPSPm.jpg',	0,	NULL,	'2023-02-21 23:28:56',	'2023-02-21 23:28:56'),
(9,	2,	'public/gallery/ORCEZ1o4mLbKGVtWq9YdHWrdPorDYmT5fSOYqq0D.jpg',	0,	NULL,	'2023-02-21 23:28:56',	'2023-02-21 23:28:56'),
(10,	2,	'public/gallery/oYcc8NSQAvBLACkWdoaFbZdY82UTKLwIusI3GLy6.jpg',	0,	NULL,	'2023-02-21 23:28:56',	'2023-02-21 23:28:56'),
(11,	3,	'public/gallery/qUVX5OTCM4WYqNSD55qfZoV06wOyyzhEpsmSO4sz.jpg',	0,	NULL,	'2023-02-22 00:07:53',	'2023-02-22 00:07:53'),
(12,	3,	'public/gallery/4W37UJxP9NWweytE7v7I8FS9l65g0JTWForFhoeG.jpg',	0,	NULL,	'2023-02-22 00:07:53',	'2023-02-22 00:07:53'),
(13,	3,	'public/gallery/DyCi6qlWOCOIUCkTiZ9XXewzYpSu9JA486KACPKv.jpg',	0,	NULL,	'2023-02-22 00:07:53',	'2023-02-22 00:07:53'),
(14,	3,	'public/gallery/ht5EDaJ7P7MpfvyBzQ9414lSdLHhCZ8yZMkdKvr9.jpg',	0,	NULL,	'2023-02-22 00:07:53',	'2023-02-22 00:07:53'),
(15,	3,	'public/gallery/q5Ph1PLEv0GAq4MRAsjbdN4dR7dqzyqIhpmEBKB3.jpg',	0,	NULL,	'2023-02-22 00:07:53',	'2023-02-22 00:07:53'),
(16,	4,	'public/gallery/4EKiEtSBwt7k2TYi2wxeCiUGQ1msLZ2mLp9uINAP.jpg',	0,	NULL,	'2023-02-22 00:15:09',	'2023-02-22 00:15:09'),
(17,	4,	'public/gallery/mU2AMvShcgHBtt5i3HZOw2M94xwqurO3bRjE8HhT.jpg',	0,	NULL,	'2023-02-22 00:15:09',	'2023-02-22 00:15:09'),
(18,	4,	'public/gallery/qu5TDpuwN1UH7hbLhQ8quby881E6PV2KxSp1Nijj.jpg',	0,	NULL,	'2023-02-22 00:15:09',	'2023-02-22 00:15:09'),
(19,	4,	'public/gallery/FrBT6R2tu3tEPtVJnyHGR6QNKZy6gbVgwFY1Pq1f.jpg',	0,	NULL,	'2023-02-22 00:15:09',	'2023-02-22 00:15:09'),
(20,	4,	'public/gallery/psvRRfik1b7S3WdcX6Hago40y4zd46S1KxIGM4Zw.jpg',	0,	NULL,	'2023-02-22 00:15:09',	'2023-02-22 00:15:09'),
(21,	5,	'public/gallery/EPkKnYwJGhLxLZGfVzNEwsg4PfhUgukzvkFXaLkw.jpg',	0,	NULL,	'2023-02-22 00:24:03',	'2023-02-22 00:24:03'),
(22,	5,	'public/gallery/s1AQcQFjMqPd1Cun9GXZ8d2Wg327dTkzarH0ZKZX.jpg',	0,	NULL,	'2023-02-22 00:24:04',	'2023-02-22 00:24:04'),
(23,	5,	'public/gallery/JM2ax5sc9lqS2BXI9MLlflOqYCy4DqoGqhzdYNr2.jpg',	0,	NULL,	'2023-02-22 00:24:04',	'2023-02-22 00:24:04'),
(24,	5,	'public/gallery/DbXnUyVsROblVrgk6CovH0K4M3sIzSdvgws0MHx7.jpg',	0,	NULL,	'2023-02-22 00:24:04',	'2023-02-22 00:24:04'),
(25,	5,	'public/gallery/pKASuG9OPDK8GXdMCwYsXnLyoRuSjbPQX4jZCtXd.jpg',	0,	NULL,	'2023-02-22 00:24:04',	'2023-02-22 00:24:04');

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('TnXYx0KHxRrbEYoaXrTEhWKhU9jhD7WvY4smqIWH',	NULL,	'127.0.0.1',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoid1RPbGFTZ01nZGtOZnlJS2dQNG9HU3pqcFVSMUtJT3ZlN2JtRnVpbCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHA6Ly9sdXhzcGFjZS50ZXN0Ijt9fQ==',	1677051691);

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `courier` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MIDTRANS',
  `payment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_price` bigint(20) NOT NULL DEFAULT '0',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `transaction_items`;
CREATE TABLE `transaction_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `users_id` bigint(20) NOT NULL,
  `products_id` bigint(20) NOT NULL,
  `transactions_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USER',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `roles`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_confirmed_at`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(1,	'dimas pradipto',	'dimas@gmail.com',	'admin',	NULL,	'$2y$10$JzybG2i2KzPJdGS2/Oz8IeLjU5rGHLEomCn5j5N0L1DGQmzJh5jn.',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-21 23:08:10',	'2023-02-21 23:08:10');

-- 2023-02-22 07:48:46
